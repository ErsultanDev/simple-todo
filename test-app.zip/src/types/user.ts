export interface UserType {
	id: number;
	name: string;
	email: string;
	address: { city: string };
}


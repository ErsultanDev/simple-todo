import React from 'react';

import Users from './views/users';

import './App.css';

function App() {
  return (
    <div className="app">
      <Users />
    </div>
  );
}

export default App;
